async function upload({ url, buffer, base64, mimeType = null }) {
  if (url) {
    return { url, mimeType };
  }

  if (base64) {
    const inferredMimeType = mimeType || (base64.match(/^data:([^;]+);base64,/) || [])[1] || null;
    return { url: base64, mimeType: inferredMimeType };
  }

  if (buffer) {
    const arrayBuffer = buffer instanceof ArrayBuffer ? buffer : buffer.buffer?.slice(buffer.byteOffset || 0, (buffer.byteOffset || 0) + buffer.byteLength);
    const bytes = new Uint8Array(arrayBuffer);
    let binary = '';
    for (const byte of bytes) binary += String.fromCharCode(byte);
    const encoded = typeof btoa === 'function' ? btoa(binary) : Buffer.from(bytes).toString('base64');
    return { url: `data:application/octet-stream;base64,${encoded}`, mimeType: mimeType || 'application/octet-stream' };
  }

  throw new Error('upload requires url, base64, or buffer');
}
export { upload };
export default upload;
