const buildBaseUrl = () => {
  return (
    process.env.APP_BASE_URL ||
    (process.env.VERCEL_URL ? `https://${process.env.VERCEL_URL}` : null) ||
    "http://localhost:3000"
  );
};

const extractJsonObject = (rawText) => {
  const cleaned = (rawText || "").replace(/```json|```/gi, "").trim();
  const firstBrace = cleaned.indexOf("{");
  const lastBrace = cleaned.lastIndexOf("}");

  if (firstBrace === -1 || lastBrace === -1 || lastBrace <= firstBrace) {
    throw new Error("Model response did not contain a JSON object");
  }

  return JSON.parse(cleaned.slice(firstBrace, lastBrace + 1));
};

const getAiConfig = () => {
  const apiKey = process.env.OPENAI_API_KEY;
  const baseUrl = process.env.OPENAI_BASE_URL || "https://api.openai.com/v1";
  const model = process.env.OPENAI_MODEL || "gpt-4.1-mini";

  if (!apiKey) {
    throw new Error("OPENAI_API_KEY not configured");
  }

  return { apiKey, baseUrl, model };
};

const callAiProvider = async (prompt) => {
  const { apiKey, baseUrl, model } = getAiConfig();
  const response = await fetch(`${baseUrl.replace(/\/$/, "")}/chat/completions`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model,
      temperature: 0.8,
      response_format: { type: "json_object" },
      messages: [
        {
          role: "system",
          content:
            "You are a precise date-night recommendation engine. Return only valid JSON that matches the requested schema.",
        },
        {
          role: "user",
          content: prompt,
        },
      ],
    }),
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`AI provider error: ${response.status} - ${errorText}`);
  }

  const data = await response.json();
  const rawText = data.choices?.[0]?.message?.content || "";
  return extractJsonObject(rawText);
};

export async function POST(request) {
  try {
    const body = await request.json();
    const { vibe, city, radius, latitude, longitude } = body;

    if (!vibe || !city || !radius) {
      return Response.json(
        { error: "Missing required fields: vibe, city, radius" },
        { status: 400 },
      );
    }

    let restaurantContext = "any great nearby restaurant that fits the vibe";
    if (latitude && longitude) {
      try {
        const placesResponse = await fetch(`${buildBaseUrl()}/api/places/search`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ latitude, longitude, radius, cuisine: null }),
        });

        if (placesResponse.ok) {
          const placesData = await placesResponse.json();
          if (placesData.restaurants && placesData.restaurants.length > 0) {
            const restaurantList = placesData.restaurants
              .slice(0, 12)
              .map(
                (r) =>
                  `- ${r.name} (${r.cuisine}, ${r.distance} mi, rating: ${r.rating || "N/A"})`,
              )
              .join("\n");
            restaurantContext = `Pick ONE restaurant from this real list of places near the user:\n${restaurantList}`;
          }
        }
      } catch (err) {
        console.error("Places fetch error:", err);
      }
    }

    const prompt = `You are a date night concierge. Recommend ONE movie and ONE restaurant that pair perfectly together for a "${vibe}" vibe in ${city} (within ${radius} miles).

${restaurantContext}

Respond ONLY with a raw JSON object. No markdown fences, no explanation, no preamble:
{
  "movie": {
    "title": "Movie Title",
    "year": 2020,
    "genre": "Genre · Subgenre",
    "runtime": "Xh Xm",
    "emoji": "single emoji that represents this film",
    "why": "One sentence on why this fits the ${vibe} vibe (max 15 words)",
    "streaming": "Netflix, Prime Video, Max, Disney+, Hulu, Apple TV+, Peacock, Paramount+, or In Theaters"
  },
  "food": {
    "name": "Exact restaurant name from the list above when a list is provided",
    "cuisine": "Cuisine type",
    "distance": "X.X",
    "why": "One sentence on why this place matches the movie and vibe (max 15 words)"
  }
}`;

    const recommendation = await callAiProvider(prompt);

    const tmdbKey = process.env.TMDB_API_KEY;
    if (tmdbKey && recommendation.movie?.title) {
      try {
        const tmdbRes = await fetch(
          `https://api.themoviedb.org/3/search/movie?query=${encodeURIComponent(recommendation.movie.title)}&year=${recommendation.movie.year || ""}&language=en-US&page=1`,
          {
            headers: {
              Authorization: `Bearer ${tmdbKey}`,
              accept: "application/json",
            },
          },
        );
        if (tmdbRes.ok) {
          const tmdbData = await tmdbRes.json();
          const hit = tmdbData.results?.[0];
          if (hit?.poster_path) {
            recommendation.movie.posterUrl = `https://image.tmdb.org/t/p/w300${hit.poster_path}`;
          }
          if (hit?.backdrop_path) {
            recommendation.movie.backdropUrl = `https://image.tmdb.org/t/p/w780${hit.backdrop_path}`;
          }
          if (hit?.vote_average) {
            recommendation.movie.tmdbRating = hit.vote_average.toFixed(1);
          }
        }
      } catch (err) {
        console.error("TMDB fetch error (non-fatal):", err);
      }
    }

    return Response.json({ recommendation });
  } catch (error) {
    console.error("Error generating recommendation:", error);
    return Response.json(
      { error: error.message || "Failed to generate recommendation" },
      { status: 500 },
    );
  }
}

export { extractJsonObject };
