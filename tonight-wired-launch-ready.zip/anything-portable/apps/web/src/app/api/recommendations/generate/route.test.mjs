import { describe, it, expect } from "vitest";
import { extractJsonObject } from "./route.js";

describe("extractJsonObject", () => {
  it("parses plain JSON", () => {
    const result = extractJsonObject('{"movie":{"title":"Test"},"food":{"name":"Spot"}}');
    expect(result.movie.title).toBe("Test");
    expect(result.food.name).toBe("Spot");
  });

  it("parses fenced JSON", () => {
    const result = extractJsonObject('```json\n{"movie":{"title":"Test"},"food":{"name":"Spot"}}\n```');
    expect(result.movie.title).toBe("Test");
  });

  it("throws when JSON is missing", () => {
    expect(() => extractJsonObject("not json")).toThrow();
  });
});
