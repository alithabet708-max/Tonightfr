import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const body = await request.json();
    const { userId, vibe, city, radius, movie, food, reaction } = body;

    if (!vibe || !city || !radius || !movie || !food) {
      return Response.json(
        { error: "Missing required fields" },
        { status: 400 },
      );
    }

    const result = await sql`
      INSERT INTO recommendations (
        user_id,
        vibe,
        city,
        radius,
        movie_title,
        movie_year,
        movie_genre,
        movie_runtime,
        movie_emoji,
        movie_why,
        movie_streaming,
        food_name,
        food_cuisine,
        food_distance,
        food_why,
        reaction
      ) VALUES (
        ${userId || null},
        ${vibe},
        ${city},
        ${radius},
        ${movie.title},
        ${movie.year},
        ${movie.genre},
        ${movie.runtime},
        ${movie.emoji},
        ${movie.why},
        ${movie.streaming || null},
        ${food.name},
        ${food.cuisine},
        ${food.distance},
        ${food.why},
        ${reaction || null}
      )
      RETURNING id
    `;

    return Response.json({ id: result[0].id });
  } catch (error) {
    console.error("Error saving recommendation:", error);
    return Response.json(
      { error: "Failed to save recommendation" },
      { status: 500 },
    );
  }
}
