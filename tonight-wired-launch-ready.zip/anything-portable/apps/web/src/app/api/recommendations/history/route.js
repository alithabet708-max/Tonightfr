import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get("userId");
    const limit = parseInt(searchParams.get("limit") || "20");

    let recommendations;

    if (userId) {
      recommendations = await sql`
        SELECT * FROM recommendations
        WHERE user_id = ${userId}
        ORDER BY created_at DESC
        LIMIT ${limit}
      `;
    } else {
      // For non-authenticated users, return empty array
      recommendations = [];
    }

    return Response.json({ recommendations });
  } catch (error) {
    console.error("Error fetching history:", error);
    return Response.json({ error: "Failed to fetch history" }, { status: 500 });
  }
}
