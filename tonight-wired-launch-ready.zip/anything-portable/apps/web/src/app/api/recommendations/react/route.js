import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const body = await request.json();
    const { id, reaction } = body;

    if (!id || !reaction) {
      return Response.json(
        { error: "Missing required fields: id, reaction" },
        { status: 400 },
      );
    }

    await sql`
      UPDATE recommendations
      SET reaction = ${reaction}
      WHERE id = ${id}
    `;

    return Response.json({ success: true });
  } catch (error) {
    console.error("Error updating reaction:", error);
    return Response.json(
      { error: "Failed to update reaction" },
      { status: 500 },
    );
  }
}
