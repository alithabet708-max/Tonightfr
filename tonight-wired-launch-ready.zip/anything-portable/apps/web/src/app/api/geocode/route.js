// Geocoding via Nominatim (OpenStreetMap) — free, no API key required
// Converts a city name string into lat/lng coordinates

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const city = searchParams.get("city");

    if (!city || city.trim().length < 2) {
      return Response.json(
        { error: "Missing or too-short city parameter" },
        { status: 400 },
      );
    }

    // Nominatim requires a User-Agent header per their usage policy
    const params = new URLSearchParams({
      q: city.trim(),
      format: "json",
      limit: "1",
      addressdetails: "1",
    });

    const nominatimRes = await fetch(
      `https://nominatim.openstreetmap.org/search?${params.toString()}`,
      {
        headers: {
          "User-Agent": "TonightApp/1.0 (date-night concierge)",
          "Accept-Language": "en",
        },
      },
    );

    if (!nominatimRes.ok) {
      throw new Error(`Nominatim error: ${nominatimRes.status}`);
    }

    const results = await nominatimRes.json();

    if (!results || results.length === 0) {
      return Response.json(
        { error: `Could not find location: "${city}"` },
        { status: 404 },
      );
    }

    const hit = results[0];
    const displayName =
      hit.address?.city ||
      hit.address?.town ||
      hit.address?.village ||
      hit.address?.county ||
      city;
    const region =
      hit.address?.state || hit.address?.country || "";

    return Response.json({
      latitude: parseFloat(hit.lat),
      longitude: parseFloat(hit.lon),
      city: displayName,
      region,
      displayName: region ? `${displayName}, ${region}` : displayName,
      raw: hit.display_name,
    });
  } catch (error) {
    console.error("Geocoding error:", error);
    return Response.json(
      { error: "Failed to geocode city" },
      { status: 500 },
    );
  }
}
