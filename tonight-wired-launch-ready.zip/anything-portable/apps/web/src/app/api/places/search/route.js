export async function POST(request) {
  try {
    const body = await request.json();
    const { cuisine, latitude, longitude, radius } = body;

    if (!latitude || !longitude || !radius) {
      return Response.json(
        { error: "Missing required fields: latitude, longitude, radius" },
        { status: 400 },
      );
    }

    const serpApiKey = process.env.SERPAPI_KEY;
    if (!serpApiKey) {
      return Response.json(
        { error: "SERPAPI_KEY not configured" },
        { status: 500 },
      );
    }

    // SerpAPI Google Maps search — real local results with ratings + hours
    const query = cuisine ? `${cuisine} restaurants` : "restaurants";
    const params = new URLSearchParams({
      engine: "google_maps",
      q: query,
      ll: `@${latitude},${longitude},14z`,
      type: "search",
      api_key: serpApiKey,
    });

    const serpResponse = await fetch(
      `https://serpapi.com/search?${params.toString()}`,
    );

    if (!serpResponse.ok) {
      throw new Error(`SerpAPI error: ${serpResponse.status}`);
    }

    const serpData = await serpResponse.json();
    const results = serpData.local_results || [];

    // Filter to radius, enrich, sort by distance
    const radiusMiles = Number(radius);
    const restaurants = results
      .map((place) => {
        const dist = calculateDistance(
          latitude,
          longitude,
          place.gps_coordinates?.latitude,
          place.gps_coordinates?.longitude,
        );
        return {
          name: place.title,
          cuisine: place.type || "Restaurant",
          distance: dist,
          rating: place.rating,
          reviewCount: place.reviews,
          address: place.address,
          placeId: place.place_id,
          phone: place.phone,
          hours: place.hours,
          thumbnail: place.thumbnail,
        };
      })
      .filter((r) => parseFloat(r.distance) <= radiusMiles)
      .sort((a, b) => parseFloat(a.distance) - parseFloat(b.distance));

    return Response.json({ restaurants });
  } catch (error) {
    console.error("Error searching places:", error);
    return Response.json(
      { error: "Failed to search restaurants" },
      { status: 500 },
    );
  }
}

// Haversine formula — distance in miles
function calculateDistance(lat1, lon1, lat2, lon2) {
  if (!lat2 || !lon2) return "?.?";
  const R = 3959;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) *
      Math.cos(toRad(lat2)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return (R * c).toFixed(1);
}

function toRad(deg) {
  return deg * (Math.PI / 180);
}
